from distutils.core import setup

setup(
    name='JuliaDoc',
    version='0.0.0',
    packages=['juliadoc',],
    license='MIT',
    long_description=open('README.md').read(),
)
